package com.devoops.rentalbrain.customer.overdue.command.service;

public interface ItemOverdueAutoCreateService {
    void createItemOverdueFromExpiredContract();
}
