package com.devoops.rentalbrain.customer.overdue.command.service;

public interface PayOverdueAutoCreateService {
    void createOverdueFromPaymentDetails();
}
