package com.devoops.rentalbrain.common.codegenerator;

public interface CodeGeneratorService {
    String nextCode(String domain, int width);
}
