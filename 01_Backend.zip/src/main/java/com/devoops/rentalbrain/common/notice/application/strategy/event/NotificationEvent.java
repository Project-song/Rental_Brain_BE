package com.devoops.rentalbrain.common.notice.application.strategy.event;

public interface NotificationEvent {
}
